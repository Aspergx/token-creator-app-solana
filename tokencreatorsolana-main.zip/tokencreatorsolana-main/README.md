# tokencreatorsolana #tokendeployersolana
Token deployer on Solana network

Watch video how to 👉 https://youtu.be/TYswtypMjDI

Join my telegram 👉 https://t.me/automatecrypto

Twitter 👉 https://twitter.com/techaddict0x
